from django.shortcuts import render
from django.http import HttpResponse
from os.path import dirname, abspath
from django_eventstream import send_event

def output(request):
    file = dirname(dirname(dirname(dirname(abspath(__file__))))) + '/20004.log'
    with open(file,'r',newline="\r\n") as f:
        msg = f.read()
    #r = HttpResponse("<pre>" + msg + "</pre>",content_type="text/event-stream")
    r = HttpResponse(msg,content_type="text/event-stream")
    print(r)
    return r

    #send_event('test', 'message', {'text': 'aaaaaaaaaa'})

# def stream_generator():
#     while True:
#         # 发送事件数据
#         # yield 'event: date\ndata: %s\n\n' % str(now())
#         # 发送数据
#         yield u'data: %s\n\n' % str(now())
#         time.sleep(2)